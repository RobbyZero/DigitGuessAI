const canvas = document.getElementById('canvas');
const ctx = canvas.getContext('2d');
let isDrawing = false;
let model = null;

ctx.lineWidth = 20;
ctx.lineCap = 'round';
ctx.strokeStyle = 'black';

function clearCanvas() {
  ctx.clearRect(0, 0, canvas.width, canvas.height);
  ctx.fillStyle = 'white';
  ctx.fillRect(0, 0, canvas.width, canvas.height);
  ctx.beginPath();
  document.getElementById('result').innerText = '';
}

clearCanvas(); 

canvas.addEventListener('mousedown', () => isDrawing = true);
canvas.addEventListener('mouseup', () => {
  isDrawing = false;
  ctx.beginPath();
});
canvas.addEventListener('mouseout', () => {
  isDrawing = false;
  ctx.beginPath();
});
canvas.addEventListener('mousemove', (e) => {
  if (!isDrawing) return;
  const rect = canvas.getBoundingClientRect();
  const x = e.clientX - rect.left;
  const y = e.clientY - rect.top;
  ctx.lineTo(x, y);
  ctx.stroke();
  ctx.beginPath();
  ctx.moveTo(x, y);
});

fetch('/model.json')
  .then(res => res.json())
  .then(data => {
    model = data;
    console.log('Model loaded');
    console.log('Model classes:', model.coef.length);
    console.log('Weights per class:', model.coef[0].length);
    console.log('Intercept length:', model.intercept.length);
  })
  .catch(err => console.error('Failed to load model:', err));

function getImageData() {
  const tempCanvas = document.createElement('canvas');
  tempCanvas.width = 28;
  tempCanvas.height = 28;
  const tempCtx = tempCanvas.getContext('2d');

  tempCtx.drawImage(canvas, 0, 0, 28, 28);

  const preview = document.getElementById('preview28');
  if (preview) {
    preview.getContext('2d').clearRect(0, 0, 28, 28);
    preview.getContext('2d').drawImage(tempCanvas, 0, 0);
  }

  const imgData = tempCtx.getImageData(0, 0, 28, 28);
  const data = imgData.data;
  const grayscale = [];

  for (let i = 0; i < data.length; i += 4) {
    const red = data[i];
    const norm = (255 - red) / 255;
    grayscale.push(norm);
  }
  return grayscale;
}

function softmax(logits) {
  const maxLogit = Math.max(...logits);
  const exps = logits.map(x => Math.exp(x - maxLogit));
  const sum = exps.reduce((a, b) => a + b, 0);
  return exps.map(e => e / sum);
}

function predict() {
  if (!model) {
    alert('Model not loaded yet!');
    return;
  }

  const input = getImageData();
  console.log('Input length:', input.length);
  console.log('First 20 pixel values:', input.slice(0, 20));
  console.log('Model classes:', model.coef.length);
  console.log('Weights per class:', model.coef[0].length);

  const W = model.coef;
  const b = model.intercept;

  const logits = W.map((weights, i) =>
    weights.reduce((sum, w, j) => sum + w * input[j], b[i])
  );

  const probs = softmax(logits);
  const prediction = probs.indexOf(Math.max(...probs));
  const confidence = (Math.max(...probs) * 100).toFixed(2);

  document.getElementById('result').innerText = `Prediction: ${prediction} (Confidence: ${confidence}%)`;
}

function testDummyInput() {
  if (!model) {
    console.log('Model not loaded yet!');
    return;
  }

  const dummyInput = new Array(784).fill(0);
  for (let i = 300; i < 400; i++) dummyInput[i] = 1;

  const W = model.coef;
  const b = model.intercept;

  const logits = W.map((weights, i) =>
    weights.reduce((sum, w, j) => sum + w * dummyInput[j], b[i])
  );

  const probs = softmax(logits);
  const pred = probs.indexOf(Math.max(...probs));
  console.log('Dummy input prediction:', pred, probs);
}
