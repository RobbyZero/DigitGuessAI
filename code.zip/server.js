const express = require('express');
const app = express();
const PORT = 5500;

app.use('/model', express.static('model'));
app.use('/', express.static('public'));

app.listen(PORT, () => {
  console.log(`Server running at http://localhost:${PORT}`);
});
