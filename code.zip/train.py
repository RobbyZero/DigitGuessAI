import csv
import numpy as np

def load_data(filename, limit=None):
    X = []
    y = []
    with open(filename, 'r') as f:
        reader = csv.reader(f)
        for i, row in enumerate(reader):
            if limit and i >= limit:
                break
            label = int(row[0])
            pixels = np.array(row[1:], dtype=float) / 255.0 
            X.append(pixels)
            y.append(label)
    return np.array(X), np.array(y)

def one_hot_encode(y, num_classes=10):
    return np.eye(num_classes)[y]

class SoftmaxModel:
    def __init__(self, input_size, num_classes):
        self.W = np.zeros((num_classes, input_size))
        self.b = np.zeros(num_classes)

    def predict(self, X):
        logits = np.dot(X, self.W.T) + self.b
        exp_logits = np.exp(logits - np.max(logits, axis=1, keepdims=True))
        return exp_logits / np.sum(exp_logits, axis=1, keepdims=True)

    def compute_loss(self, probs, y_true):
        m = y_true.shape[0]
        log_likelihood = -np.log(probs[range(m), y_true])
        loss = np.sum(log_likelihood) / m
        return loss

    def train(self, X, y, epochs=100, lr=0.1):
        y_one_hot = one_hot_encode(y)
        m = X.shape[0]

        for epoch in range(epochs):
            probs = self.predict(X)
            loss = self.compute_loss(probs, y)
            
            grad_logits = probs - y_one_hot
            dW = np.dot(grad_logits.T, X) / m
            db = np.sum(grad_logits, axis=0) / m

            self.W -= lr * dW
            self.b -= lr * db

            if (epoch+1) % 10 == 0:
                print(f"Epoch {epoch+1}/{epochs}, Loss: {loss:.4f}")

model = SoftmaxModel(784, 10)

print("Loading training data...")
X_train, y_train = load_data('mnist_train.csv', limit=10000) 

print("Training model...")
model.train(X_train, y_train, epochs=50, lr=0.1)

import json
model_json = {
    "coef": model.W.tolist(),
    "intercept": model.b.tolist()
}
with open("model.json", "w") as f:
    json.dump(model_json, f)

print("Model saved as model.json")
